from flask import Flask,render_template,request

import pymysql
d_connection = None
tb_cursor = None

app = Flask(__name__)

@app.route("/")
def index():
    #return "Hello World"
    allData = getAllStudentData()
    print(allData)
    return render_template("index.html",data = allData)

    
@app.route("/add",methods=["GET","POST"])
def addStudent():
    if request.method == "POST":
        data = request.form
        isiInserted = insertIntoTable(data['txtName'],data['txtPhone'],data['txtDob'],data['txtAddress'])
        if(isiInserted):
            message = "Insertion Sucesss"    
        else:
            message = "Insertion Error" 

        return render_template("add.html",message=message)
    return render_template("add.html")



#function to connect with db
def connectToDb():
    global db_connection, tb_cursor
    db_connection = pymysql.connect(host="localhost",user="root",passwd="",database="student_db",port=3306)
    if (db_connection):
        print("Connected to database")
        tb_cursor = db_connection.cursor()

    else:
        print("Not connected")

#function to disconnect with db   
def disconnectDb():
    db_connection.close()
    tb_cursor.close()


#getting all records from table

def getAllStudentData():
    connectToDb()
    fetchQuery = "select * from student_info;"
    tb_cursor.execute(fetchQuery)
    allFetchedData = tb_cursor.fetchall()
    disconnectDb()
    return allFetchedData 


def insertIntoTable(name,contact,dob,address):
    connectToDb()
    insertQuery = "INSERT INTO student_info(Name,Contact,DOB,Address) VALUES(%s, %s, %s, %s);"
    tb_cursor.execute(insertQuery,(name,contact,dob,address))
    db_connection.commit()
    disconnectDb()
    return True




if __name__=='__main__':
    app.run(debug=True) 